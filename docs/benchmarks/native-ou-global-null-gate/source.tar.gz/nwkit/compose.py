import json
import os
import sys
from typing import Any

import pandas as pd

from nwkit.clade_mapping import build_clade_mapping, projected_root_split
from nwkit.root import transfer_root_with_taxon_mode
from nwkit.rooting_state import require_rooted
from nwkit.transfer import (
    REPORT_COLUMNS,
    parse_property_specs,
    parse_root_edge_policies,
    transfer_properties,
)
from nwkit.util import (
    get_tree_property_names,
    read_tree,
    validate_distinct_output_paths,
)


def _resolve_manifest_path(value, base_dir):
    if value in (None, "", "-"):
        return value
    if os.path.isabs(str(value)):
        return str(value)
    return os.path.join(base_dir, str(value))


def _load_manifest(path):
    if path in (None, ""):
        return {}
    with open(path) as handle:
        manifest = json.load(handle)
    if not isinstance(manifest, dict):
        raise ValueError("Composition manifest must contain a JSON object.")
    base_dir = os.path.dirname(os.path.realpath(path))
    for key in ("root", "name", "support", "length"):
        if key in manifest:
            manifest[key] = _resolve_manifest_path(manifest[key], base_dir)
    normalized_properties = list()
    for entry in manifest.get("properties", []):
        if not isinstance(entry, dict):
            raise ValueError("Each manifest 'properties' entry must be an object.")
        if "path" not in entry or "source" not in entry:
            raise ValueError("Manifest property entries require 'path' and 'source'.")
        normalized = dict(entry)
        normalized["path"] = _resolve_manifest_path(entry["path"], base_dir)
        normalized["target"] = entry.get("target", entry["source"])
        normalized_properties.append(normalized)
    manifest["properties"] = normalized_properties
    if "root_edge_policies" in manifest and not isinstance(
        manifest["root_edge_policies"], dict
    ):
        raise ValueError("Manifest 'root_edge_policies' must contain a JSON object.")
    return manifest


def _parse_property_source(raw):
    if "@" not in str(raw):
        raise ValueError(
            "--property-source must use SOURCE[@TARGET]@PATH or SOURCE=TARGET@PATH syntax."
        )
    property_spec, path = str(raw).rsplit("@", 1)
    if "=" in property_spec:
        source_prop, target_prop = property_spec.split("=", 1)
    else:
        source_prop = property_spec
        target_prop = property_spec
    specs = parse_property_specs(
        property_maps=["{}={}".format(source_prop, target_prop)]
    )
    return {
        "path": path,
        "source": specs[0][0],
        "target": specs[0][1],
    }


def _root_report_row(source_path, target, source, mapping, status, reason, taxon_mode):
    root_match = next(match for match in mapping.matches if match.target.is_root)
    split = projected_root_split(source, mapping.shared_taxa)
    split_text = ""
    if split is not None:
        split_text = "{}|{}".format(
            ",".join(sorted(split[0])),
            ",".join(sorted(split[1])),
        )
    row: dict[str, Any] = {column: "" for column in REPORT_COLUMNS}
    row.update(
        {
            "source_file": source_path,
            "target_branch_id": 0,
            "target_node_class": "root",
            "target_taxa": ",".join(sorted(str(name) for name in target.leaf_names())),
            "shared_descendant_taxa": ",".join(sorted(mapping.shared_taxa)),
            "shared_split": split_text,
            "source_taxa": ",".join(sorted(str(name) for name in source.leaf_names())),
            "match_status": root_match.status,
            "match_basis": "split",
            "projection_only": root_match.status == "projected_match",
            "source_property": "root",
            "target_property": "root",
            "status": status,
            "reason": reason,
            "projected_value_allowed": "",
            "taxon_mode": taxon_mode,
            "num_shared_taxa": len(mapping.shared_taxa),
            "num_target_only_taxa": len(mapping.target_only_taxa),
            "num_source_only_taxa": len(mapping.source_only_taxa),
        }
    )
    return row


def _write_report(rows, path):
    from nwkit.tree_outputs import write_table_report

    write_table_report(pd.DataFrame(rows, columns=REPORT_COLUMNS), path)


def _configured_sources(args):
    manifest = _load_manifest(getattr(args, "manifest", None))
    manifest_root_edge_policies = parse_root_edge_policies(
        manifest.get("root_edge_policies", {})
    )
    cli_root_edge_policies = parse_root_edge_policies(
        getattr(args, "root_edge_policy", None)
    )
    root_edge_policies = dict(manifest_root_edge_policies)
    root_edge_policies.update(cli_root_edge_policies)
    sources = {
        "root": getattr(args, "root_source", None) or manifest.get("root"),
        "name": getattr(args, "name_source", None) or manifest.get("name"),
        "support": getattr(args, "support_source", None) or manifest.get("support"),
        "length": getattr(args, "length_source", None) or manifest.get("length"),
        "properties": list(manifest.get("properties", [])),
        "root_edge_policies": root_edge_policies,
        "manifest_root_edge_policies": manifest_root_edge_policies,
        "cli_root_edge_policies": cli_root_edge_policies,
    }
    sources["properties"].extend(
        _parse_property_source(raw)
        for raw in (getattr(args, "property_source", None) or [])
    )
    return sources


def compose_main(args):
    validate_distinct_output_paths(
        [
            ("--outfile", getattr(args, "outfile", None)),
            ("--report", getattr(args, "report", None)),
        ]
    )
    sources = _configured_sources(args)
    if (
        not any(sources[key] for key in ("root", "name", "support", "length"))
        and not sources["properties"]
    ):
        raise ValueError("At least one composition source must be specified.")
    taxon_mode = getattr(args, "taxon_mode", "exact")
    policy = getattr(args, "policy", "compatible-only")
    match_basis = getattr(args, "match_basis", "clade")
    allow_projected_values = bool(getattr(args, "allow_projected_values", False))
    source_format = getattr(args, "source_format", "auto")
    target = read_tree(
        args.infile,
        args.format,
        args.quoted_node_names,
        rooted=getattr(args, "input_rooted", "auto"),
    )
    collect_report = getattr(args, "report", None) not in (None, "")
    report_rows = list()
    status_counts: dict[str, int] = {}
    output_properties = set(get_tree_property_names(target))
    failures = list()

    root_source_path = sources["root"]
    if root_source_path:
        root_source = read_tree(
            root_source_path,
            source_format,
            args.quoted_node_names,
            rooted=getattr(args, "root_source_rooted", "auto"),
        )
        mapping = build_clade_mapping(
            target=target, source=root_source, taxon_mode=taxon_mode
        )
        root_match = next(match for match in mapping.matches if match.target.is_root)
        if policy == "strict" and root_match.status == "projected_match":
            reason = "strict_policy_requires_exact_root_match"
            root_status = "projected_match_rejected"
            if collect_report:
                report_rows.append(
                    _root_report_row(
                        source_path=root_source_path,
                        target=target,
                        source=root_source,
                        mapping=mapping,
                        status=root_status,
                        reason=reason,
                        taxon_mode=taxon_mode,
                    )
                )
            status_counts[root_status] = status_counts.get(root_status, 0) + 1
            failures.append(reason)
        else:
            try:
                require_rooted(
                    root_source,
                    "Root transfer requires a rooted source tree.",
                    "--root-source-rooted",
                )
                target = transfer_root_with_taxon_mode(
                    tree_to=target,
                    tree_from=root_source,
                    taxon_mode=taxon_mode,
                    verbose=True,
                )
                root_status = "transferred"
                if collect_report:
                    report_rows.append(
                        _root_report_row(
                            source_path=root_source_path,
                            target=target,
                            source=root_source,
                            mapping=mapping,
                            status=root_status,
                            reason="matching_root_split",
                            taxon_mode=taxon_mode,
                        )
                    )
                status_counts[root_status] = status_counts.get(root_status, 0) + 1
            except ValueError as exc:
                root_status = "unmatched"
                if collect_report:
                    report_rows.append(
                        _root_report_row(
                            source_path=root_source_path,
                            target=target,
                            source=root_source,
                            mapping=mapping,
                            status=root_status,
                            reason=str(exc),
                            taxon_mode=taxon_mode,
                        )
                    )
                status_counts[root_status] = status_counts.get(root_status, 0) + 1
                failures.append(str(exc))

    built_in_sources = (
        ("name", sources["name"], ("name", "name"), "all", False),
        ("support", sources["support"], ("support", "support"), "intnode", True),
        ("length", sources["length"], ("length", "length"), "all", True),
    )
    for (
        source_kind,
        source_path,
        property_spec,
        target_class,
        exclude_root,
    ) in built_in_sources:
        if not source_path:
            continue
        source_tree = read_tree(
            source_path,
            source_format,
            args.quoted_node_names,
            rooted=getattr(args, source_kind + "_source_rooted", "auto"),
        )
        result = transfer_properties(
            target=target,
            source=source_tree,
            property_specs=[property_spec],
            target_class=target_class,
            taxon_mode=taxon_mode,
            policy=policy,
            align_roots=True,
            source_label=source_path,
            exclude_root=exclude_root,
            match_basis=match_basis,
            allow_projected_values=allow_projected_values,
            allow_target_reroot=False,
            root_edge_policies=sources["root_edge_policies"],
            collect_report=collect_report,
        )
        target = result["tree"]
        report_rows.extend(result["rows"])
        for status, count in result["status_counts"].items():
            status_counts[status] = status_counts.get(status, 0) + count
        output_properties.update(result["output_properties"])
        if result["error"] is not None:
            failures.append(str(result["error"]))

    for property_source in sources["properties"]:
        source_path = property_source["path"]
        source_tree = read_tree(
            source_path,
            property_source.get("format", source_format),
            args.quoted_node_names,
            rooted=getattr(args, "property_source_rooted", "auto"),
        )
        property_spec = parse_property_specs(
            property_maps=[
                "{}={}".format(property_source["source"], property_source["target"])
            ]
        )
        property_root_edge_policies = dict(sources["manifest_root_edge_policies"])
        if "root_edge_policy" in property_source:
            property_root_edge_policies.update(
                parse_root_edge_policies(
                    {
                        property_source["target"]: property_source["root_edge_policy"],
                    }
                )
            )
        property_root_edge_policies.update(sources["cli_root_edge_policies"])
        result = transfer_properties(
            target=target,
            source=source_tree,
            property_specs=property_spec,
            target_class=property_source.get("target_class", "all"),
            taxon_mode=taxon_mode,
            policy=policy,
            align_roots=True,
            source_label=source_path,
            match_basis=match_basis,
            allow_projected_values=allow_projected_values,
            allow_target_reroot=False,
            root_edge_policies=property_root_edge_policies,
            collect_report=collect_report,
        )
        target = result["tree"]
        report_rows.extend(result["rows"])
        for status, count in result["status_counts"].items():
            status_counts[status] = status_counts.get(status, 0) + count
        output_properties.update(result["output_properties"])
        if result["error"] is not None:
            failures.append(str(result["error"]))

    if failures and policy == "strict":
        _write_report(report_rows, getattr(args, "report", None))
        raise ValueError("Strict composition failed: {}".format(" | ".join(failures)))
    transferred = status_counts.get("transferred", 0)
    skipped = sum(
        count
        for status, count in status_counts.items()
        if status not in ("transferred", "filled")
    )
    sys.stderr.write(
        "Composition report: transferred={}, skipped={}\n".format(transferred, skipped)
    )
    outformat = args.outformat
    has_internal_names = any(
        not node.is_leaf and node.name not in (None, "") for node in target.traverse()
    )
    if outformat == "auto" and has_internal_names:
        outformat = 1
    from nwkit.tree_outputs import write_tree_with_tables

    write_tree_with_tables(
        target,
        args,
        format=outformat,
        props=output_properties,
        tables=[
            (
                getattr(args, "report", None),
                pd.DataFrame(report_rows, columns=REPORT_COLUMNS),
            )
        ],
    )
