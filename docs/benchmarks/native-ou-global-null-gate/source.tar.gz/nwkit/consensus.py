import math
import multiprocessing
import sys
from collections import defaultdict
from concurrent.futures import FIRST_COMPLETED, ProcessPoolExecutor, wait
from itertools import chain, islice
from typing import Any, Iterable

import pandas as pd
from ete4 import Tree

from nwkit.rooting_state import get_rooting_info, set_rooting_info
from nwkit.rooting_state import require_rooted as check_rooted
from nwkit.util import (
    MISSING_SUPPORT_VALUE,
    TREE_FORMAT_PROP,
    count_set_bits,
    get_subtree_leaf_bitmasks,
    iter_tree_strings,
    read_tree,
    remove_singleton,
    validate_unique_named_leaves,
    write_tree,
)


def _scale_support(freq, support_scale):
    if support_scale == "percent":
        return freq * 100.0
    if support_scale == "proportion":
        return freq
    raise ValueError("Unsupported '--support-scale': {}".format(support_scale))


def _bit_to_order_map(leaf_names):
    return {1 << index: index for index in range(len(leaf_names))}


def _iter_mask_bits(mask):
    remaining = int(mask)
    while remaining:
        bit = remaining & -remaining
        yield bit
        remaining ^= bit


def _masks_are_compatible(mask1, mask2):
    overlap = mask1 & mask2
    return (overlap == 0) or (overlap == mask1) or (overlap == mask2)


def _orient_unrooted_split(mask, all_mask, anchor_bit):
    """Represent an unrooted split by the side away from a fixed anchor."""
    return (all_mask ^ mask) if (mask & anchor_bit) else mask


def _branch_observation_mask(mask, all_mask, anchor_bit, comparison):
    if comparison == "rooted":
        return mask
    complement = all_mask ^ mask
    # Keep pendant-edge lengths keyed by their singleton tip, including the
    # anchor tip. Non-trivial splits are oriented away from the anchor.
    if count_set_bits(mask) == 1:
        return mask
    if count_set_bits(complement) == 1:
        return complement
    return _orient_unrooted_split(mask, all_mask, anchor_bit)


def _read_tree_weights(weight_tsv, num_trees=None):
    if weight_tsv in ["", None]:
        return None if num_trees is None else [1.0] * num_trees
    weight_source = sys.stdin if weight_tsv == "-" else weight_tsv
    weight_df = pd.read_csv(weight_source, sep="\t")
    if "weight" not in weight_df.columns:
        raise ValueError("--weight-tsv must contain a 'weight' column.")
    if weight_df["weight"].isna().any():
        raise ValueError("--weight-tsv contains missing values in 'weight'.")
    weights: list[float | None]
    if "tree_id" in weight_df.columns:
        if weight_df["tree_id"].isna().any():
            raise ValueError("--weight-tsv contains missing values in 'tree_id'.")
        parsed_rows = list()
        for _, row in weight_df.iterrows():
            try:
                tree_id_value = float(row["tree_id"])
            except ValueError as exc:
                raise ValueError(
                    "--weight-tsv 'tree_id' values must be integers."
                ) from exc
            if not tree_id_value.is_integer():
                raise ValueError("--weight-tsv 'tree_id' values must be integers.")
            tree_id = int(tree_id_value)
            if tree_id < 1 or (num_trees is not None and tree_id > num_trees):
                raise ValueError(
                    "--weight-tsv tree_id is out of range: {}".format(tree_id)
                )
            parsed_rows.append((tree_id, row["weight"]))
        expected_count = (
            num_trees
            if num_trees is not None
            else max((tree_id for tree_id, _ in parsed_rows), default=0)
        )
        weights = [None] * expected_count
        for tree_id, weight_value in parsed_rows:
            if weights[tree_id - 1] is not None:
                raise ValueError(
                    "Duplicated 'tree_id' values are not supported in --weight-tsv."
                )
            try:
                weight = float(weight_value)
            except (TypeError, ValueError) as exc:
                raise ValueError(
                    "--weight-tsv 'weight' values must be numeric."
                ) from exc
            if not math.isfinite(weight):
                raise ValueError("Tree weights must be finite.")
            weights[tree_id - 1] = weight
    else:
        if num_trees is not None and len(weight_df.index) != num_trees:
            raise ValueError(
                "--weight-tsv must contain exactly one row per input tree."
            )
        weights = []
        for weight_value in weight_df["weight"].tolist():
            try:
                weight = float(weight_value)
            except (TypeError, ValueError) as exc:
                raise ValueError(
                    "--weight-tsv 'weight' values must be numeric."
                ) from exc
            if not math.isfinite(weight):
                raise ValueError("Tree weights must be finite.")
            weights.append(weight)
    validated_weights: list[float] = []
    for current_weight in weights:
        if current_weight is None:
            raise ValueError("--weight-tsv must define weights for every input tree.")
        if current_weight <= 0:
            raise ValueError("Tree weights must be positive.")
        validated_weights.append(current_weight)
    return validated_weights


def _normalize_relative_weights(weights):
    """Scale weights for internal arithmetic without changing their ratios."""
    max_weight = max(weights)
    return [weight / max_weight for weight in weights]


def _weighted_median(values, weights):
    sorted_pairs = sorted(zip(values, weights, strict=True), key=lambda pair: pair[0])
    total_weight = math.fsum(weight for _, weight in sorted_pairs)
    cumulative_weight = 0.0
    for value, weight in sorted_pairs:
        cumulative_weight += weight
        if cumulative_weight >= (total_weight / 2.0):
            return value
    return sorted_pairs[-1][0]


def _aggregate_branch_lengths(observations, method):
    if method == "none":
        return dict()
    out = dict()
    for mask, records in observations.items():
        if method == "mean" and isinstance(records, tuple):
            running_mean, weight_sum = records
            out[mask] = None if weight_sum == 0 else running_mean
            continue
        values = [value for value, _ in records if value is not None]
        weights = [weight for value, weight in records if value is not None]
        if len(values) == 0:
            out[mask] = None
            continue
        if method == "mean":
            out[mask] = math.fsum(
                value * weight for value, weight in zip(values, weights, strict=True)
            ) / math.fsum(weights)
        elif method == "median":
            out[mask] = _weighted_median(values, weights)
        else:
            raise ValueError("Unsupported '--branch-length': {}".format(method))
    return out


def _validate_threads(threads):
    try:
        threads = int(threads)
    except (TypeError, ValueError) as exc:
        raise ValueError("'--threads' must be an integer.") from exc
    if threads <= 0:
        raise ValueError("'--threads' must be positive.")
    return threads


def _get_process_pool_context():
    try:
        return multiprocessing.get_context("forkserver")
    except ValueError:
        return None


def _initialize_clade_collection(first_tree):
    validate_unique_named_leaves(
        first_tree, option_name="--infile", context=" for 'consensus'"
    )
    leaf_names = list(first_tree.leaf_names())
    leaf_name_to_bit = {leaf_name: index for index, leaf_name in enumerate(leaf_names)}
    all_mask = (1 << len(leaf_names)) - 1
    return leaf_names, leaf_name_to_bit, all_mask


def _check_clade_rooting(tree, comparison, required, message, option="--input-rooted"):
    if required or (comparison == "rooted" and get_rooting_info(tree).rooted is False):
        check_rooted(tree, message, option)


def _collect_single_tree_clade_stats(
    tree,
    tree_weight,
    tree_index,
    leaf_names,
    leaf_name_to_bit,
    collect_branch_lengths=True,
    branch_length_method=None,
    comparison="rooted",
    require_rooted=False,
):
    if branch_length_method is None:
        branch_length_method = "median" if collect_branch_lengths else "none"
    all_mask = (1 << len(leaf_names)) - 1
    anchor_bit = 1 << leaf_name_to_bit[leaf_names[0]]
    clade_weights: defaultdict[int, float] = defaultdict(float)
    branch_length_observations: dict[int, Any] = (
        {} if branch_length_method == "mean" else defaultdict(list)
    )
    validate_unique_named_leaves(
        tree, option_name="--infile", context=" for 'consensus'"
    )
    _check_clade_rooting(
        tree,
        comparison,
        require_rooted,
        "Input tree {} is not rooted; rooted clade collection requires rooted trees.".format(
            tree_index
        ),
    )
    if set(tree.leaf_names()) != set(leaf_names):
        raise ValueError(
            "Leaf labels must be identical across all input trees for consensus."
        )
    subtree_masks = get_subtree_leaf_bitmasks(tree, leaf_name_to_bit)
    branch_length_by_mask = dict()
    clade_masks = set()
    for node, mask in subtree_masks.items():
        num_tips = count_set_bits(mask)
        is_direct_one_tip = node.is_root and node.is_leaf and len(leaf_names) == 1
        if branch_length_method != "none" and ((not node.is_root) or is_direct_one_tip):
            observation_mask = _branch_observation_mask(
                mask,
                all_mask,
                anchor_bit,
                comparison,
            )
            dist_value = None if (node.dist is None) else float(node.dist)
            if observation_mask not in branch_length_by_mask:
                branch_length_by_mask[observation_mask] = dist_value
            else:
                previous_value = branch_length_by_mask[observation_mask]
                branch_length_by_mask[observation_mask] = (
                    None
                    if previous_value is None or dist_value is None
                    else previous_value + dist_value
                )
        if node.is_root:
            continue
        if comparison == "rooted":
            if (num_tips <= 1) or (num_tips >= len(leaf_names)):
                continue
            clade_mask = mask
        else:
            if min(num_tips, len(leaf_names) - num_tips) <= 1:
                continue
            clade_mask = _orient_unrooted_split(mask, all_mask, anchor_bit)
        clade_masks.add(clade_mask)
    for mask in clade_masks:
        clade_weights[mask] = tree_weight
    for mask, dist_value in branch_length_by_mask.items():
        if branch_length_method == "mean":
            branch_length_observations[mask] = (
                (0.0, 0.0) if dist_value is None else (dist_value, tree_weight)
            )
        else:
            branch_length_observations[mask].append((dist_value, tree_weight))
    return (
        leaf_names,
        leaf_name_to_bit,
        all_mask,
        dict(clade_weights),
        dict(branch_length_observations),
    )


def _merge_clade_stats(target_clade_weights, target_branch_length_observations, source):
    source_clade_weights, source_branch_length_observations = source
    for mask, weight in source_clade_weights.items():
        target_clade_weights[mask] += weight
    for mask, observations in source_branch_length_observations.items():
        if isinstance(observations, tuple):
            source_mean, source_weight = observations
            current = target_branch_length_observations.get(mask)
            if current is None or current[1] == 0.0:
                target_branch_length_observations[mask] = observations
                continue
            if source_weight == 0.0:
                continue
            current_mean, current_weight = current
            combined_weight = current_weight + source_weight
            target_branch_length_observations[mask] = (
                math.fsum(
                    (
                        current_mean * (current_weight / combined_weight),
                        source_mean * (source_weight / combined_weight),
                    )
                ),
                combined_weight,
            )
        else:
            target_branch_length_observations[mask].extend(observations)


def _collect_tree_string_chunk_clade_stats(payload):
    (
        records,
        format,
        quoted_node_names,
        leaf_names,
        collect_branch_lengths,
        branch_length_method,
        comparison,
        require_rooted,
        input_rooted,
    ) = payload
    leaf_name_to_bit = {leaf_name: index for index, leaf_name in enumerate(leaf_names)}
    clade_weights: defaultdict[int, float] = defaultdict(float)
    branch_length_observations: dict[int, Any] = (
        {} if branch_length_method == "mean" else defaultdict(list)
    )
    for tree_index, tree_string, tree_weight in records:
        tree = read_tree(
            tree_string, format, quoted_node_names, quiet=True, rooted=input_rooted
        )
        _, _, _, tree_clade_weights, tree_branch_length_observations = (
            _collect_single_tree_clade_stats(
                tree=tree,
                tree_weight=tree_weight,
                tree_index=tree_index,
                leaf_names=leaf_names,
                leaf_name_to_bit=leaf_name_to_bit,
                collect_branch_lengths=collect_branch_lengths,
                branch_length_method=branch_length_method,
                comparison=comparison,
                require_rooted=require_rooted,
            )
        )
        _merge_clade_stats(
            target_clade_weights=clade_weights,
            target_branch_length_observations=branch_length_observations,
            source=(tree_clade_weights, tree_branch_length_observations),
        )
    return dict(clade_weights), dict(branch_length_observations)


def _collect_clade_stats_from_tree_strings(
    tree_strings,
    tree_weights,
    format,
    quoted_node_names,
    collect_branch_lengths=True,
    threads=1,
    branch_length_method=None,
    comparison="rooted",
    require_rooted=False,
    input_rooted="auto",
):
    tree_string_iterator = iter(tree_strings)
    try:
        first_tree_string = next(tree_string_iterator)
    except StopIteration:
        raise ValueError("No input trees were found for consensus.") from None
    threads = _validate_threads(threads)
    if branch_length_method is None:
        branch_length_method = "median" if collect_branch_lengths else "none"
    first_tree = read_tree(
        first_tree_string, format, quoted_node_names, quiet=True, rooted=input_rooted
    )
    leaf_names, leaf_name_to_bit, all_mask = _initialize_clade_collection(first_tree)

    def tree_weight(tree_index):
        if tree_weights is None:
            return 1.0
        if tree_index > len(tree_weights):
            raise ValueError(
                "--weight-tsv must contain exactly one row per input tree."
            )
        return tree_weights[tree_index - 1]

    _, _, _, first_clade_weights, first_branch_length_observations = (
        _collect_single_tree_clade_stats(
            tree=first_tree,
            tree_weight=tree_weight(1),
            tree_index=1,
            leaf_names=leaf_names,
            leaf_name_to_bit=leaf_name_to_bit,
            collect_branch_lengths=collect_branch_lengths,
            branch_length_method=branch_length_method,
            comparison=comparison,
            require_rooted=require_rooted,
        )
    )
    clade_weights: defaultdict[int, float] = defaultdict(float, first_clade_weights)
    branch_length_observations: dict[int, Any] = (
        {} if branch_length_method == "mean" else defaultdict(list)
    )
    for mask, observations in first_branch_length_observations.items():
        if isinstance(observations, tuple):
            branch_length_observations[mask] = observations
        else:
            branch_length_observations[mask].extend(observations)
    records: Iterable[tuple[int, Any, float]] = (
        (tree_index, tree_string, tree_weight(tree_index))
        for tree_index, tree_string in enumerate(tree_string_iterator, start=2)
    )
    if threads > 1:
        prefetched_records = list(islice(records, 64))
        records = chain(prefetched_records, records)
        if len(prefetched_records) < 64:
            threads = 1
    if threads <= 1:
        chunk_result = _collect_tree_string_chunk_clade_stats(
            (
                records,
                format,
                quoted_node_names,
                leaf_names,
                collect_branch_lengths,
                branch_length_method,
                comparison,
                require_rooted,
                input_rooted,
            )
        )
        _merge_clade_stats(
            target_clade_weights=clade_weights,
            target_branch_length_observations=branch_length_observations,
            source=chunk_result,
        )
    else:
        executor_kwargs = {"max_workers": threads}
        process_pool_context = _get_process_pool_context()
        if process_pool_context is not None:
            executor_kwargs["mp_context"] = process_pool_context
        with ProcessPoolExecutor(**executor_kwargs) as executor:
            futures: set[Any] = set()
            records_exhausted = False
            while futures or not records_exhausted:
                while len(futures) < threads * 2 and not records_exhausted:
                    chunk = list(islice(records, 32))
                    if not chunk:
                        records_exhausted = True
                        break
                    payload = (
                        chunk,
                        format,
                        quoted_node_names,
                        leaf_names,
                        collect_branch_lengths,
                        branch_length_method,
                        comparison,
                        require_rooted,
                        input_rooted,
                    )
                    futures.add(
                        executor.submit(_collect_tree_string_chunk_clade_stats, payload)
                    )
                if not futures:
                    continue
                completed, futures = wait(futures, return_when=FIRST_COMPLETED)
                for future in completed:
                    chunk_result = future.result()
                    _merge_clade_stats(
                        target_clade_weights=clade_weights,
                        target_branch_length_observations=branch_length_observations,
                        source=chunk_result,
                    )
    return (
        leaf_names,
        leaf_name_to_bit,
        all_mask,
        dict(clade_weights),
        dict(branch_length_observations),
    )


def _collect_clade_stats(
    trees,
    tree_weights,
    collect_branch_lengths=True,
    comparison="rooted",
):
    first_tree = trees[0]
    leaf_names, leaf_name_to_bit, all_mask = _initialize_clade_collection(first_tree)
    clade_weights: defaultdict[int, float] = defaultdict(float)
    branch_length_observations: defaultdict[int, list[Any]] = defaultdict(list)
    for tree_index, (tree, tree_weight) in enumerate(
        zip(trees, tree_weights, strict=True), start=1
    ):
        _, _, _, tree_clade_weights, tree_branch_length_observations = (
            _collect_single_tree_clade_stats(
                tree=tree,
                tree_weight=tree_weight,
                tree_index=tree_index,
                leaf_names=leaf_names,
                leaf_name_to_bit=leaf_name_to_bit,
                collect_branch_lengths=collect_branch_lengths,
                branch_length_method="median" if collect_branch_lengths else "none",
                comparison=comparison,
            )
        )
        _merge_clade_stats(
            target_clade_weights=clade_weights,
            target_branch_length_observations=branch_length_observations,
            source=(tree_clade_weights, tree_branch_length_observations),
        )
    return (
        leaf_names,
        leaf_name_to_bit,
        all_mask,
        dict(clade_weights),
        dict(branch_length_observations),
    )


def _get_method_min_freq(method, min_freq):
    if method == "strict":
        return 1.0
    if method == "majority":
        return 0.5 + 10**-12
    if method == "greedy":
        return min_freq
    raise ValueError("Unsupported '--method': {}".format(method))


def _select_consensus_masks(clade_weights, total_weight, min_freq):
    selected_masks: list[tuple[Any, Any, float]] = []
    candidates = list()
    for mask, weight in clade_weights.items():
        freq = weight / total_weight
        if freq >= min_freq:
            candidates.append((mask, weight, freq))
    candidates.sort(key=lambda item: (-item[1], -count_set_bits(item[0]), int(item[0])))
    for mask, weight, freq in candidates:
        if all(
            _masks_are_compatible(mask, selected_mask)
            for selected_mask, _, _ in selected_masks
        ):
            selected_masks.append((mask, weight, freq))
    return selected_masks


def _build_consensus_subtree(
    parent_mask,
    selected_masks,
    support_by_mask,
    dist_by_mask,
    bit_to_name,
    bit_to_order,
    all_mask,
):
    # Selected clades are laminar. Join their current maximal subclades from
    # smallest to largest, without recursion or rescanning every candidate at
    # every ancestor. Taxa need not be contiguous in the input leaf order.
    owner = {}
    minimum_order = {}
    for bit in _iter_mask_bits(parent_mask):
        leaf = Tree()
        leaf.name = bit_to_name[bit]
        leaf.dist = dist_by_mask.get(bit)
        leaf.support = MISSING_SUPPORT_VALUE
        owner[bit] = leaf
        minimum_order[leaf] = bit_to_order[bit]
    masks = {mask for mask in selected_masks if mask & ~parent_mask == 0}
    masks.add(parent_mask)
    _assemble_consensus_clades(
        masks, owner, minimum_order, all_mask, dist_by_mask, support_by_mask
    )
    return owner[parent_mask & -parent_mask]


def _assemble_consensus_clades(
    masks, owner, minimum_order, all_mask, dist_by_mask, support_by_mask
):
    for mask in sorted(masks, key=lambda value: (count_set_bits(value), value)):
        node = Tree()
        node.dist = None if mask == all_mask else dist_by_mask.get(mask)
        node.support = (
            None
            if mask == all_mask
            else support_by_mask.get(mask, MISSING_SUPPORT_VALUE)
        )
        children = set()
        for bit in _iter_mask_bits(mask):
            children.add(owner[bit])
            owner[bit] = node
        for child in sorted(children, key=minimum_order.__getitem__):
            node.add_child(child)
        minimum_order[node] = min(minimum_order[child] for child in children)


def _build_consensus_tree(
    leaf_names, all_mask, selected_masks, support_by_mask, dist_by_mask
):
    bit_to_name = {1 << index: leaf_name for index, leaf_name in enumerate(leaf_names)}
    bit_to_order = _bit_to_order_map(leaf_names)
    consensus_tree = _build_consensus_subtree(
        parent_mask=all_mask,
        selected_masks=selected_masks,
        support_by_mask=support_by_mask,
        dist_by_mask=dist_by_mask,
        bit_to_name=bit_to_name,
        bit_to_order=bit_to_order,
        all_mask=all_mask,
    )
    for node in consensus_tree.traverse():
        node.props[TREE_FORMAT_PROP] = 0
    return consensus_tree


def _annotate_reference_tree(
    reference_tree,
    leaf_name_to_bit,
    num_leaves,
    clade_weights,
    total_weight,
    support_scale,
    comparison="rooted",
):
    validate_unique_named_leaves(
        reference_tree, option_name="--reference", context=" for 'consensus'"
    )
    subtree_masks = get_subtree_leaf_bitmasks(reference_tree, leaf_name_to_bit)
    all_mask = (1 << num_leaves) - 1
    anchor_bit = 1 << leaf_name_to_bit[next(iter(leaf_name_to_bit))]
    for node, mask in subtree_masks.items():
        if node.is_root or node.is_leaf:
            continue
        num_tips = count_set_bits(mask)
        if comparison == "rooted":
            if num_tips >= num_leaves:
                continue
            comparison_mask = mask
        else:
            if min(num_tips, num_leaves - num_tips) <= 1:
                continue
            comparison_mask = _orient_unrooted_split(mask, all_mask, anchor_bit)
        freq = clade_weights.get(comparison_mask, 0.0) / total_weight
        node.support = _scale_support(freq, support_scale)
    reference_tree.props[TREE_FORMAT_PROP] = 0
    return reference_tree


def consensus_main(args):
    method = getattr(args, "method", "greedy")
    branch_length = getattr(args, "branch_length", "none")
    comparison = getattr(args, "comparison", "rooted")
    weight_tsv = getattr(args, "weight_tsv", None)
    if comparison not in ("rooted", "unrooted"):
        raise ValueError("Unsupported '--comparison': {}".format(comparison))
    if (args.min_freq < 0.0) or (args.min_freq > 1.0):
        raise ValueError("'--min-freq' must be between 0 and 1.")
    raw_tree_strings = iter(iter_tree_strings(args.infile))
    try:
        first_tree_string = next(raw_tree_strings)
    except StopIteration:
        raise ValueError("No input trees were found for consensus.") from None
    tree_count = [0]

    def counted_tree_strings():
        for tree_string in chain((first_tree_string,), raw_tree_strings):
            tree_count[0] += 1
            yield tree_string

    raw_tree_weights = _read_tree_weights(weight_tsv)
    tree_weights = (
        None
        if raw_tree_weights is None
        else _normalize_relative_weights(raw_tree_weights)
    )
    (
        leaf_names,
        leaf_name_to_bit,
        all_mask,
        clade_weights,
        branch_length_observations,
    ) = _collect_clade_stats_from_tree_strings(
        tree_strings=counted_tree_strings(),
        tree_weights=tree_weights,
        format=args.format,
        quoted_node_names=args.quoted_node_names,
        collect_branch_lengths=(branch_length != "none"),
        threads=getattr(args, "threads", 1),
        branch_length_method=branch_length,
        comparison=comparison,
        input_rooted=getattr(args, "input_rooted", "auto"),
    )
    num_trees = tree_count[0]
    if tree_weights is not None and len(tree_weights) != num_trees:
        raise ValueError("--weight-tsv must contain exactly one row per input tree.")
    sys.stderr.write("Number of input trees = {:,}\n".format(num_trees))
    total_weight = float(num_trees) if tree_weights is None else math.fsum(tree_weights)
    if args.reference not in ["", None]:
        reference_tree = read_tree(
            args.reference,
            args.reference_format,
            args.quoted_node_names,
            rooted=getattr(args, "reference_rooted", "auto"),
        )
        _check_clade_rooting(
            reference_tree,
            comparison,
            False,
            "'--reference' must be rooted for rooted consensus comparison.",
            "--reference-rooted",
        )
        if set(reference_tree.leaf_names()) != set(leaf_names):
            raise ValueError(
                "Leaf labels in '--reference' must match the input tree collection."
            )
        output_tree = _annotate_reference_tree(
            reference_tree=reference_tree,
            leaf_name_to_bit=leaf_name_to_bit,
            num_leaves=len(leaf_names),
            clade_weights=clade_weights,
            total_weight=total_weight,
            support_scale=args.support_scale,
            comparison=comparison,
        )
    else:
        selected_masks = _select_consensus_masks(
            clade_weights=clade_weights,
            total_weight=total_weight,
            min_freq=_get_method_min_freq(method, args.min_freq),
        )
        support_by_mask = {
            mask: _scale_support(freq, args.support_scale)
            for mask, _, freq in selected_masks
        }
        dist_by_mask = _aggregate_branch_lengths(
            observations=branch_length_observations,
            method=branch_length,
        )
        output_tree = _build_consensus_tree(
            leaf_names=leaf_names,
            all_mask=all_mask,
            selected_masks=[mask for mask, _, _ in selected_masks],
            support_by_mask=support_by_mask,
            dist_by_mask=dist_by_mask,
        )
        output_tree = remove_singleton(
            output_tree,
            verbose=False,
            preserve_branch_length=True,
        )
    set_rooting_info(output_tree, comparison == "rooted", source="consensus")
    write_tree(output_tree, args, format=0)
